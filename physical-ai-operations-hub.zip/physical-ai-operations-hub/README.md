# Physical AI Operations Hub

A Next.js + Supabase internal operations application for physical-AI data collection garages. It includes device inventory, staff directory, recording sessions, productivity logs, QA audit views, maintenance issues, private file uploads, and a management report page.

## Included

- Responsive internal dashboard and navigation.
- Device, staff, recording-session and maintenance issue entry forms.
- Searchable registers for devices, staff, sessions, productivity, QA, issues and uploaded files.
- Supabase Auth email/password sign-in when configured.
- PostgreSQL schema with relationships, indexes, analytics view and baseline Row Level Security (RLS).
- Private Supabase Storage bucket for PDFs, Office documents, CSV, images and videos.
- Demo mode with sample records so the interface can be previewed without credentials.

## 1. Requirements

- Node.js 20.9+ and npm
- A Supabase project

## 2. Run locally

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open http://localhost:3000.

By default `.env.example` enables demo mode. The sample data is in-memory and resets on refresh; it is not connected to a persistent database.

## 3. Connect Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Copy the Project URL and anon/public key from Project Settings → API.
4. Put them in `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
NEXT_PUBLIC_DEMO_MODE=false
```

5. Restart the dev server.
6. In Supabase Authentication, enable Email provider and create user accounts for staff who need access.
7. Add a matching row in `public.staff` with that user's `auth_user_id`, `employee_code`, `full_name`, role and status `active`.
8. Sign in with the created account.

**Important:** The SQL provides a baseline internal RLS policy set. Before production, review it against your organization’s exact site boundaries and roles. In particular, add site-scoped policies if multiple sites must not see one another's data, and ensure staff can only see their own personal records where required. Do not expose a Supabase service-role key in browser code.

## 4. File storage

The SQL creates a private Supabase Storage bucket named `operations-files` and policies for authenticated users. The app uploads objects to that bucket and stores file metadata in `public.files`. Download links are short-lived signed URLs.

The initial upload flow is suitable for ordinary operational evidence. For very large videos or unstable connections, implement resumable/multipart uploads and consider S3 or Cloudflare R2. Keep buckets private and apply retention, encryption, malware scanning, and access logging according to company policy.

## 5. Database model

The migration creates these tables:

- `sites`
- `staff`
- `shifts`
- `devices`
- `device_assignments`
- `recording_sessions`
- `productivity_logs`
- `quality_audits`
- `device_issues`
- `files`
- `daily_reports`
- `activity_logs`

It also creates `device_performance_summary` for dashboard reporting.

## 6. Production deployment

Deploy the Next.js project to Vercel or an AWS-hosted Node environment. Configure the same environment variables in the hosting provider. Use a custom company domain, enforce MFA where available, restrict Supabase project access, configure database backups and storage lifecycle rules, and test RLS with each role before inviting the workforce.

## 7. Current MVP limitations

- Demo data is illustrative only and resets when the browser refreshes.
- Supabase mode persists devices, staff, sessions, maintenance issues and file metadata.
- Productivity and QA currently have searchable data views; entry forms, detailed audit checklists and fully automated KPI aggregation are the next implementation layer.
- The report page provides a current-record summary and browser print; scheduled email/WhatsApp delivery and AI-generated narrative summaries require a connected workflow/service and explicit configuration.
- Device and staff editing/deactivation, assignment lifecycle UI, attendance capture, shift handover and full audit checklist builder are planned extensions, not yet implemented.
- The chart uses illustrative trend data until a time-series productivity query is configured.

## Data definitions

- Device utilization = device occupied/recording time divided by scheduled available time.
- Commander productivity = validated productive hours divided by target hours.
- QA pass rate = total passed checks divided by total audited checks (weighted by check count).
- Rejected recording rate should be calculated from audited recording/session outcomes, not inferred from device status.

Store timestamps in UTC (`timestamptz`) and display them in the site's configured timezone (initially Asia/Kolkata).
