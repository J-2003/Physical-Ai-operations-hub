import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Physical AI Operations Hub', description: 'Internal device, workforce, productivity and quality management platform.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
