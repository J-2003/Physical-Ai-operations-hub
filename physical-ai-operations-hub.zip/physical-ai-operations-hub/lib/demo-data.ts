export const demoDevices = [
 {device_id:'d1',device_code:'DEV-001',device_model:'Capture Rig A',current_status:'in_use',serial_number:'SN-1001',site_id:'Garage Bengaluru'},
 {device_id:'d2',device_code:'DEV-002',device_model:'Capture Rig A',current_status:'in_use',serial_number:'SN-1002',site_id:'Garage Bengaluru'},
 {device_id:'d3',device_code:'DEV-003',device_model:'Capture Rig B',current_status:'idle',serial_number:'SN-1003',site_id:'Garage Bengaluru'},
 {device_id:'d4',device_code:'DEV-004',device_model:'Capture Rig B',current_status:'maintenance',serial_number:'SN-1004',site_id:'Garage Bengaluru'},
 {device_id:'d5',device_code:'DEV-005',device_model:'Capture Rig C',current_status:'in_use',serial_number:'SN-1005',site_id:'Garage Bengaluru'},
 {device_id:'d6',device_code:'DEV-006',device_model:'Capture Rig C',current_status:'available',serial_number:'SN-1006',site_id:'Garage Bengaluru'}
];
export const demoStaff = [
 {staff_id:'s1',employee_code:'CMD-001',full_name:'Arun Kumar',role:'commander',department:'Data Collection',status:'active'},
 {staff_id:'s2',employee_code:'CMD-002',full_name:'Priya S',role:'commander',department:'Data Collection',status:'active'},
 {staff_id:'s3',employee_code:'SUP-001',full_name:'Rahul M',role:'supervisor',department:'Operations',status:'active'},
 {staff_id:'s4',employee_code:'QA-001',full_name:'Sneha R',role:'qa',department:'Quality',status:'active'},
 {staff_id:'s5',employee_code:'MGR-001',full_name:'Site Manager',role:'site_manager',department:'Management',status:'active'}
];
export const demoSessions = [
 {session_id:'r1',task_name:'Kitchen object handling',device_id:'DEV-001',staff_id:'Arun Kumar',start_time:'2026-11-13T08:00:00+05:30',duration_minutes:95,recordings_completed:18,session_status:'completed'},
 {session_id:'r2',task_name:'Table organization',device_id:'DEV-002',staff_id:'Priya S',start_time:'2026-11-13T09:00:00+05:30',duration_minutes:120,recordings_completed:24,session_status:'completed'},
 {session_id:'r3',task_name:'Package sorting',device_id:'DEV-005',staff_id:'Arun Kumar',start_time:'2026-11-13T10:30:00+05:30',duration_minutes:75,recordings_completed:14,session_status:'needs_review'}
];
export const demoIssues = [
 {issue_id:'i1',device_id:'DEV-004',issue_category:'Connectivity',description:'Device disconnects during capture',priority:'high',status:'in_progress',reported_at:'2026-11-13T09:15:00+05:30'},
 {issue_id:'i2',device_id:'DEV-003',issue_category:'Calibration',description:'Calibration verification required',priority:'medium',status:'open',reported_at:'2026-11-13T10:10:00+05:30'}
];
