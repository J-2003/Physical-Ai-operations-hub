-- Physical AI Operations Hub: PostgreSQL schema for Supabase
create extension if not exists pgcrypto;

create table if not exists public.sites (
  site_id uuid primary key default gen_random_uuid(), site_name text not null,
  location text, site_manager uuid, status text not null default 'active',
  created_at timestamptz not null default now()
);
create table if not exists public.staff (
  staff_id uuid primary key default gen_random_uuid(), auth_user_id uuid unique references auth.users(id) on delete set null,
  employee_code text not null unique, full_name text not null, email text,
  role text not null check (role in ('admin','general_manager','site_manager','supervisor','qa','commander')),
  department text, site_id uuid references public.sites(site_id), joining_date date,
  status text not null default 'active' check (status in ('active','inactive','on_leave')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.sites drop constraint if exists sites_site_manager_fkey;
alter table public.sites add constraint sites_site_manager_fkey foreign key (site_manager) references public.staff(staff_id) on delete set null;
create table if not exists public.shifts (
  shift_id uuid primary key default gen_random_uuid(), site_id uuid not null references public.sites(site_id),
  shift_name text not null, start_time time not null, end_time time not null, created_at timestamptz default now()
);
create table if not exists public.devices (
  device_id uuid primary key default gen_random_uuid(), device_code text not null unique,
  serial_number text, device_model text, site_id uuid references public.sites(site_id),
  purchase_date date, current_status text not null default 'available'
    check (current_status in ('available','in_use','idle','maintenance','damaged','inactive')),
  last_maintenance date, notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.device_assignments (
  assignment_id uuid primary key default gen_random_uuid(), device_id uuid not null references public.devices(device_id),
  staff_id uuid not null references public.staff(staff_id), shift_id uuid references public.shifts(shift_id),
  assigned_at timestamptz not null default now(), returned_at timestamptz,
  condition_before text, condition_after text, assigned_by uuid references public.staff(staff_id),
  check (returned_at is null or returned_at >= assigned_at)
);
create unique index if not exists one_open_assignment_per_device on public.device_assignments(device_id) where returned_at is null;
create table if not exists public.recording_sessions (
  session_id uuid primary key default gen_random_uuid(), session_code text unique,
  device_id uuid not null references public.devices(device_id), staff_id uuid not null references public.staff(staff_id),
  shift_id uuid references public.shifts(shift_id), task_name text not null,
  start_time timestamptz not null, end_time timestamptz, duration_minutes numeric(10,2),
  recordings_completed integer not null default 0 check (recordings_completed >= 0),
  session_status text not null default 'in_progress' check (session_status in ('in_progress','completed','cancelled','needs_review')),
  notes text, created_at timestamptz not null default now(), check (end_time is null or end_time >= start_time)
);
create table if not exists public.productivity_logs (
  log_id uuid primary key default gen_random_uuid(), device_id uuid not null references public.devices(device_id),
  staff_id uuid not null references public.staff(staff_id), shift_id uuid references public.shifts(shift_id),
  log_date date not null, target_hours numeric(8,2) not null default 0, actual_hours numeric(8,2) not null default 0,
  target_tasks integer not null default 0, completed_tasks integer not null default 0, downtime_minutes integer not null default 0,
  notes text, created_at timestamptz not null default now(), unique(device_id,staff_id,shift_id,log_date)
);
create table if not exists public.quality_audits (
  audit_id uuid primary key default gen_random_uuid(), session_id uuid not null references public.recording_sessions(session_id),
  device_id uuid not null references public.devices(device_id), auditor_id uuid references public.staff(staff_id),
  audit_date timestamptz not null default now(), total_checks integer not null default 0,
  passed_checks integer not null default 0, failed_checks integer not null default 0,
  quality_score numeric(5,2) generated always as (case when total_checks > 0 then round((passed_checks::numeric / total_checks) * 100,2) else 0 end) stored,
  feedback text, audit_status text not null default 'completed' check (audit_status in ('pending','completed','rework_required')),
  check (passed_checks + failed_checks <= total_checks)
);
create table if not exists public.device_issues (
  issue_id uuid primary key default gen_random_uuid(), device_id uuid not null references public.devices(device_id),
  reported_by uuid references public.staff(staff_id), issue_category text not null, description text not null,
  priority text not null default 'medium' check (priority in ('low','medium','high','critical')),
  reported_at timestamptz not null default now(), assigned_to uuid references public.staff(staff_id),
  resolution text, resolved_at timestamptz, status text not null default 'open' check (status in ('open','in_progress','resolved','closed'))
);
create table if not exists public.files (
  file_id uuid primary key default gen_random_uuid(), file_name text not null, file_type text not null,
  mime_type text, storage_provider text not null default 'supabase', storage_bucket text not null default 'operations-files',
  storage_path text not null unique, file_size_bytes bigint, uploaded_by uuid references public.staff(staff_id),
  device_id uuid references public.devices(device_id), session_id uuid references public.recording_sessions(session_id),
  issue_id uuid references public.device_issues(issue_id), description text, uploaded_at timestamptz not null default now()
);
create table if not exists public.daily_reports (
  report_id uuid primary key default gen_random_uuid(), site_id uuid references public.sites(site_id),
  report_date date not null, shift_id uuid references public.shifts(shift_id), total_devices integer default 0,
  active_devices integer default 0, total_recordings integer default 0, total_hours numeric(10,2) default 0,
  average_quality numeric(5,2), summary text, generated_at timestamptz not null default now(),
  unique(site_id, report_date, shift_id)
);
create table if not exists public.activity_logs (
  activity_id uuid primary key default gen_random_uuid(), user_id uuid references public.staff(staff_id),
  action text not null, entity_type text not null, entity_id uuid, details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_devices_site_status on public.devices(site_id,current_status);
create index if not exists idx_staff_site_role on public.staff(site_id,role);
create index if not exists idx_sessions_device_start on public.recording_sessions(device_id,start_time desc);
create index if not exists idx_sessions_staff_start on public.recording_sessions(staff_id,start_time desc);
create index if not exists idx_productivity_date on public.productivity_logs(log_date desc,device_id,staff_id);
create index if not exists idx_quality_session on public.quality_audits(session_id,audit_date desc);
create index if not exists idx_issues_status on public.device_issues(status,priority,reported_at desc);
create index if not exists idx_files_device_date on public.files(device_id,uploaded_at desc);
create index if not exists idx_activity_created on public.activity_logs(created_at desc);

-- Analytics view: one row per device, current operational summary.
create or replace view public.device_performance_summary as
select d.device_id,d.device_code,d.device_model,d.current_status,d.site_id,
 coalesce(sum(p.actual_hours),0)::numeric(10,2) as actual_hours,
 coalesce(sum(p.target_hours),0)::numeric(10,2) as target_hours,
 coalesce(sum(p.completed_tasks),0)::bigint as completed_tasks,
 coalesce(sum(p.downtime_minutes),0)::bigint as downtime_minutes
from public.devices d left join public.productivity_logs p on p.device_id=d.device_id
 and p.log_date = (now() at time zone 'Asia/Kolkata')::date
group by d.device_id;

-- Authentication helpers and conservative RLS baseline.
create or replace function public.current_staff_role() returns text language sql stable security definer set search_path=public as $$
  select role from public.staff where auth_user_id = auth.uid() and status='active' limit 1;
$$;
create or replace function public.is_management() returns boolean language sql stable security definer set search_path=public as $$
  select coalesce(public.current_staff_role() in ('admin','general_manager','site_manager'),false);
$$;

alter table public.sites enable row level security;
alter table public.staff enable row level security;
alter table public.shifts enable row level security;
alter table public.devices enable row level security;
alter table public.device_assignments enable row level security;
alter table public.recording_sessions enable row level security;
alter table public.productivity_logs enable row level security;
alter table public.quality_audits enable row level security;
alter table public.device_issues enable row level security;
alter table public.files enable row level security;
alter table public.daily_reports enable row level security;
alter table public.activity_logs enable row level security;

-- Internal authenticated users can read site operational data. Writes are role-gated.
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['sites','staff','shifts','devices','device_assignments','recording_sessions','productivity_logs','quality_audits','device_issues','files','daily_reports','activity_logs'] LOOP
   EXECUTE format('drop policy if exists %I on public.%I', t||'_read_authenticated', t);
   EXECUTE format('create policy %I on public.%I for select to authenticated using (true)', t||'_read_authenticated', t);
 END LOOP;
END $$;
create policy "management_write_sites" on public.sites for all to authenticated using (public.is_management()) with check (public.is_management());
create policy "management_write_staff" on public.staff for all to authenticated using (public.is_management()) with check (public.is_management());
create policy "management_write_devices" on public.devices for all to authenticated using (public.is_management()) with check (public.is_management());
create policy "staff_write_assignments" on public.device_assignments for all to authenticated using (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor')) with check (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor'));
create policy "staff_write_sessions" on public.recording_sessions for all to authenticated using (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor','commander')) with check (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor','commander'));
create policy "staff_write_productivity" on public.productivity_logs for all to authenticated using (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor')) with check (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor'));
create policy "qa_write_audits" on public.quality_audits for all to authenticated using (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor','qa')) with check (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor','qa'));
create policy "staff_write_issues" on public.device_issues for all to authenticated using (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor')) with check (public.current_staff_role() in ('admin','general_manager','site_manager','supervisor'));
create policy "staff_upload_files" on public.files for insert to authenticated with check (true);
create policy "management_delete_files" on public.files for delete to authenticated using (public.is_management());
create policy "management_write_reports" on public.daily_reports for all to authenticated using (public.is_management()) with check (public.is_management());
create policy "insert_activity_logs" on public.activity_logs for insert to authenticated with check (true);

-- Create a private storage bucket. File objects are not publicly accessible.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('operations-files','operations-files',false,536870912,
 array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv',
 'image/jpeg','image/png','image/webp','video/mp4','video/quicktime','video/webm'])
on conflict (id) do update set public=false;
create policy "authenticated_read_operations_files" on storage.objects for select to authenticated using (bucket_id='operations-files');
create policy "authenticated_upload_operations_files" on storage.objects for insert to authenticated with check (bucket_id='operations-files');
create policy "management_delete_operations_files" on storage.objects for delete to authenticated using (bucket_id='operations-files' and public.is_management());
