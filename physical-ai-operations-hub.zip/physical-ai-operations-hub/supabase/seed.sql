-- Optional starter seed. Run after schema.sql. Replace site details as required.
insert into public.sites (site_name,location,status)
values ('Bengaluru Garage','Bengaluru, Karnataka, India','active')
on conflict do nothing;

-- Demo users are not created here. Create staff through the app after authentication is configured.
